using FMODUnity;
using Interactions.Interaction_System.Interaction_Base_Class;
using Player.PlayerMovement.Movement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace UI.Menu
{
    public class PauseMenu : MonoBehaviour
    {
        [SerializeField] private GameObject pauseMenu;
        [SerializeField] private GameObject settingsMenu;
        [SerializeField] private Button backButton;
        [SerializeField] private GameObject crosshairCanvas;
        [SerializeField] private string menuScene;
        private bool _isPaused;
        private PlayerController _playerController;
        private GameObject _player;

        public EventReference mainMenuMusic;

        private void Start()
        {
            _playerController = FindFirstObjectByType<PlayerController>();
            _player = _playerController.gameObject;
            ResumeGame();
        }

        private void Update()
        {
            crosshairCanvas.SetActive(!_isPaused);
            if (InputManager.Input.UI.Pause.WasPressedThisFrame() && !InputManager.Input.Inspection.enabled)
            {
                if (_isPaused)
                {
                    ResumeGame();
                }
                else
                {
                    PauseGame();
                }
            }
        }

        public void ResumeGame()
        {
            _isPaused = false;
            backButton.onClick.Invoke();
            pauseMenu.SetActive(false);
            settingsMenu.SetActive(false);
            _playerController.CameraActive = true;
            InputManager.Input.Player.Enable();
            InputManager.Input.Interaction.Enable();
        }

        private void PauseGame()
        {
            InputManager.Input.Player.Disable();
            InputManager.Input.Interaction.Disable();
            _isPaused = true;
            settingsMenu.SetActive(false);
            pauseMenu.SetActive(true);
            _playerController.CameraActive = false;
        }

        public void BackToMenu()
        {
            MusicManager.I.PlayMusic(mainMenuMusic);
            Destroy(_player);
            SceneManager.LoadScene(menuScene);
        }
    }
}